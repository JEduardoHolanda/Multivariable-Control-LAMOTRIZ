function lib( libInfo )
% Customize library

% Copyright 2017 The MathWorks, Inc.

libInfo.Annotation = sprintf('Custom moist air domain and library for the Vehicle HVAC System example');

end
